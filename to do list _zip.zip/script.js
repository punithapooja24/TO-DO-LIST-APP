const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

// Load tasks from localStorage
window.onload = () => {
  const savedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
  savedTasks.forEach(task => renderTask(task.text, task.completed));
};


function saveTasks() {
  const tasks = [];
  document.querySelectorAll("li").forEach(li => {
    tasks.push({
      text: li.querySelector("span").innerText,
      completed: li.classList.contains("completed")
    });
  });
  localStorage.setItem("tasks", JSON.stringify(tasks));
}


function addTask() {
  const text = taskInput.value.trim();
  if (text === "") {
    alert("Task cannot be empty!");
    return;
  }
  renderTask(text, false);
  saveTasks();
  taskInput.value = "";
}


function renderTask(text, completed) {
  const li = document.createElement("li");
  if (completed) li.classList.add("completed");

  const span = document.createElement("span");
  span.innerText = text;
  span.onclick = () => {
    li.classList.toggle("completed");
    saveTasks();
  };

  const actions = document.createElement("div");
  actions.className = "actions";

  const editBtn = document.createElement("button");
  editBtn.innerText = "Edit";
  editBtn.className = "edit";
  editBtn.onclick = () => editTask(li, span);

  const deleteBtn = document.createElement("button");
  deleteBtn.innerText = "Delete";
  deleteBtn.className = "delete";
  deleteBtn.onclick = () => {
    li.remove();
    saveTasks();
  };

  actions.appendChild(editBtn);
  actions.appendChild(deleteBtn);

  li.appendChild(span);
  li.appendChild(actions);
  taskList.appendChild(li);
}

// existing task
function editTask(li, span) {
  const input = document.createElement("input");
  input.type = "text";
  input.value = span.innerText;
  li.replaceChild(input, span);

  const saveBtn = document.createElement("button");
  saveBtn.innerText = "Save";
  saveBtn.className = "save";
  saveBtn.onclick = () => {
    if (input.value.trim() === "") {
      alert("Task cannot be empty!");
      return;
    }
    span.innerText = input.value;
    li.replaceChild(span, input);
    li.querySelector(".actions").replaceChild(editBtn, saveBtn);
    saveTasks();
  };

  const editBtn = li.querySelector(".edit");
  li.querySelector(".actions").replaceChild(saveBtn, editBtn);
}
